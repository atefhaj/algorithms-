# Roulette : Casino Game

A Pen created on CodePen.io. Original URL: [https://codepen.io/disus/pen/RwaejZe](https://codepen.io/disus/pen/RwaejZe).

Just a simple Roulette Wheel  based on https://codepen.io/daniandl/pen/mMQmGV